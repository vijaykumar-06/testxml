﻿using System;
using System.Linq;
using System.Text;
using System.Collections;
using System.Xml.Linq;
using System.Xml;
using Microsoft.XmlDiffPatch;
using System.IO;
using System.Collections.Generic;

namespace small_prgrms
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = "UNA:+.? '"
                            + "UNB+UNOC:3+2021000969+4441963198+180525:1225+3VAL2MJV6EH9IX+KMSV7HMD+CUSDECU-IE++1++1'"
                            + "UNH+EDIFACT+CUSDEC:D:96B:UN:145050'"
                            + "BGM+ZEM:::EX+09SEE7JPUV5HC06IC6+Z'"
                            + "LOC+17+IT044100'"
                            + "LOC+18+SOL'"
                            + "LOC+35+SE'"
                            + "LOC+36+TZ'"
                            + "LOC+116+SE003033'"
                            + "DTM+9:20090527:102'"
                            + "DTM+268:20090626:102'"
                            + "DTM+182:20090527:102'";
            input = input.Remove(input.Length - 1);
            string[] output;
            List<String> list = new List<String>();
            var lines = input.Split('\'');
            foreach (var line in lines)
            {
                if (line.Substring(0, 3) == "LOC")
                {
                    var ind = line.Split('+');
                    string x = ind[1] + " & " + ind[2];
                    list.Add(x);
                }
            }
            output = list.ToArray();

            foreach (string s in output)
            {
                Console.WriteLine(s);
            }
            Console.ReadLine();
        }
    }

}