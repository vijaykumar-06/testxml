﻿using System;
using System.Linq;
using System.Text;
using System.Collections;
using System.Xml.Linq;
using System.Xml;
using Microsoft.XmlDiffPatch;
using System.IO;
using System.Collections.Generic;

namespace small_prgrms
{
    class Program
    {
        static void Main(string[] args)
        {
            List<String> list = new List<String>();
            string[] output;
            XmlDocument doc = new XmlDocument();
            var xmlStr = File.ReadAllText("../../Test.xml");
            doc.LoadXml(xmlStr);
            string xpath = "InputDocument/DeclarationList/Declaration/DeclarationHeader/Reference";
            XmlNode node1 = doc.SelectSingleNode(xpath);
            XmlNodeList nodes = doc.SelectNodes(xpath);
            foreach (XmlNode n in nodes)
            {
                if (n.Attributes[0].Value == "MWB" || n.Attributes[0].Value == "TRV" || n.Attributes[0].Value == "CAR")
                {
                    list.Add(n.ChildNodes[0].InnerText);
                }
            }
            output = list.ToArray();
            foreach (string s in output)
            {
                Console.WriteLine(s);
            }
            Console.ReadLine();
        }
    }


}