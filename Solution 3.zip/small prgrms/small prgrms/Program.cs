﻿using System;
using System.Linq;
using System.Text;
using System.Collections;
using System.Xml.Linq;
using System.Xml;
using Microsoft.XmlDiffPatch;
using System.IO;
using System.Collections.Generic;

namespace small_prgrms
{
    class Program
    {
        static void Main(string[] args)
        {
            //Sample input with details
            string input = "<InputDocument>"
                + "<DeclarationList>"
                 + "<Declaration Command='DEFAULT' Version='5.13'>"
                        + "<DeclarationHeader>"
                            + "<Jurisdiction>IE</Jurisdiction>"
                            + "<CWProcedure>IMPORT</CWProcedure>"
                                        + "<DeclarationDestination>CUSTOMSWAREIE</DeclarationDestination>"
                            + "<DocumentRef>71Q0019681</DocumentRef>"
                            + "<SiteID>DUB</SiteID>"
                            + "<AccountCode>G0779837</AccountCode>"
                        + "</DeclarationHeader>"
                    + "</Declaration>"
                + "</DeclarationList>"
            + "</InputDocument>";
            Service s = new Service();
            int i = s.CheckXml(input);
        }
    }


}